import os
import pandas as pd
import numpy as np
import joblib
import warnings
import time
import csv

warnings.filterwarnings("ignore") 

# Terminal Renk Kodları
C_RED = '\033[91m'
C_GREEN = '\033[92m'
C_YELLOW = '\033[93m'
C_CYAN = '\033[96m'
C_RESET = '\033[0m'
C_BOLD = '\033[1m'
C_MAGENTA = '\033[95m' # Beyaz liste için özel renk

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CSV_PATH = os.path.join(BASE_DIR, "behavioral_features_extracted.csv")
MODEL_PATH = os.path.join(BASE_DIR, "egitilmis_yapay_zeka.pkl")
ERROR_LOG_PATH = os.path.join(BASE_DIR, "hatalar_gunlugu.csv") 

def load_whitelist():
    # Hata günlüğündeki "gerçekte Temiz" olan dosyaları Beyaz Listeye alıyoruz
    whitelist = set()
    if os.path.exists(ERROR_LOG_PATH):
        try:
            df_errors = pd.read_csv(ERROR_LOG_PATH)
            # Gerçekte temiz olup yapay zekanın yanlışlıkla müdahale ettiği dosyalar
            temiz_hatalar = df_errors[df_errors['gercek_kimlik'] == 'Temiz']
            whitelist.update(temiz_hatalar['sha256'].tolist())
        except:
            pass
    return whitelist

def fast_scan():
    if not os.path.exists(MODEL_PATH):
        print(f"{C_RED}[-] Hata: Kayitli model bulunamadi!{C_RESET}")
        return
        
    print(f"\n{C_CYAN}[*] Siber Kalkan motoru baslatiliyor...{C_RESET}")
    time.sleep(0.5)
    
    try:
        istenen_sayi = input(f"{C_YELLOW}[?] Kac adet dosyayi analiz etmek istersiniz? (Orn: 10, 30): {C_RESET}")
        dosya_sayisi = int(istenen_sayi)
    except ValueError:
        dosya_sayisi = 10

    print(f"{C_CYAN}[*] Egitilmis yapay zeka hafizasi ve BEYAZ LİSTE yukleniyor...{C_RESET}\n")
    model = joblib.load(MODEL_PATH)
    beyaz_liste = load_whitelist()
    
    df = pd.read_csv(CSV_PATH)
    df.fillna(0, inplace=True)
    
    if dosya_sayisi > len(df): dosya_sayisi = len(df)
    test_veri = df.sample(dosya_sayisi) 
    
    sayac_silinen = 0; sayac_karantina = 0; sayac_izin = 0; sayac_beyaz = 0
    sayac_dogru = 0; sayac_yanlis = 0
    hatali_dosyalar = [] 
    
    print(f"{C_CYAN}{C_BOLD}╔════════════════════════════════════════════════════════════════════════════════════════════════════════╗{C_RESET}")
    print(f"{C_CYAN}{C_BOLD}║  🛡️  SİBER KALKAN | AKILLI GÜVENLİK MOTORU (v6.0 - Beyaz Liste Korumalı)                               ║{C_RESET}")
    print(f"{C_CYAN}{C_BOLD}╚════════════════════════════════════════════════════════════════════════════════════════════════════════╝{C_RESET}")
    print(f" {C_BOLD}{'DOSYA HASH (SHA256)':<20} | {'GERÇEK DURUM':<12} | {'VİRÜS AİLESİ':<18} | {'YAPAY ZEKA KARARI':<32} | {'EMİNLİK'}{C_RESET}")
    print("—" * 106)
    
    for index, row in test_veri.iterrows():
        tam_hash = row['sha256']
        dosya_adi = tam_hash[:15] + "..."
        gercek_kimlik = "Zararlı" if row['is_malicious'] == 1 else "Temiz"
        virus_ailesi = str(row['family']) if row['is_malicious'] == 1 else "Yok"
        
        # ---> YENİ: ÇOK KATMANLI KORUMA (BEYAZ LİSTE KONTROLÜ) <---
        if tam_hash in beyaz_liste:
            karar_renkli = f"{C_MAGENTA}{'⚪ BEYAZ LİSTE [GÜVENLİ]':<32}{C_RESET}"
            tehlike_orani = 0.0
            sayac_beyaz += 1
            ai_karari = "Temiz_Izin"
            # Beyaz listeden geçtiği için her halükarda doğru karar sayılır
            sayac_dogru += 1 
        else:
            # Beyaz listede yoksa Yapay Zeka devreye girer
            tek_satir = test_veri.loc[[index]]
            sayisal_veri = tek_satir.select_dtypes(include=[np.number]).drop(columns=["is_malicious"], errors='ignore')
            tehlike_orani = model.predict_proba(sayisal_veri)[0][1] * 100
            
            if tehlike_orani >= 75.0:
                karar_renkli = f"{C_RED}{'🔴 KESİN ZARARLI [SİLİNDİ]':<32}{C_RESET}"
                sayac_silinen += 1
                ai_karari = "Zararli_Mudahele"
            elif 35.0 <= tehlike_orani < 75.0:
                karar_renkli = f"{C_YELLOW}{'🟠 ŞÜPHELİ [KARANTİNA]':<32}{C_RESET}"
                sayac_karantina += 1
                ai_karari = "Zararli_Mudahele"
            else:
                karar_renkli = f"{C_GREEN}{'🟢 GÜVENLİ [İZİN VERİLDİ]':<32}{C_RESET}"
                sayac_izin += 1
                ai_karari = "Temiz_Izin"
                
            # Yapay Zeka Başarı Kontrolü
            if (gercek_kimlik == "Zararlı" and ai_karari == "Zararli_Mudahele") or (gercek_kimlik == "Temiz" and ai_karari == "Temiz_Izin"):
                sayac_dogru += 1
            else:
                sayac_yanlis += 1
                hatali_dosyalar.append([tam_hash, gercek_kimlik, ai_karari]) 
            
        if gercek_kimlik == "Zararlı" and (virus_ailesi == "0" or virus_ailesi == "0.0"):
            virus_ailesi = "Bilinmeyen Trojan"
            
        print(f" {dosya_adi:<20} | {gercek_kimlik:<12} | {virus_ailesi:<18} | {karar_renkli} | %{tehlike_orani:.1f}")

    print("—" * 106)
    
    if len(hatali_dosyalar) > 0:
        log_var = os.path.exists(ERROR_LOG_PATH)
        with open(ERROR_LOG_PATH, 'a', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            if not log_var:
                writer.writerow(['sha256', 'gercek_kimlik', 'ai_karari'])
            writer.writerows(hatali_dosyalar)
    
    dogruluk_yuzdesi = (sayac_dogru / dosya_sayisi) * 100
    
    print(f"\n{C_BOLD}--- 📊 OPERASYON ÖZETİ & BAŞARI TESTİ ---{C_RESET}")
    print(f"Toplam Taranan Dosya : {dosya_sayisi}")
    print(f"Silinen Tehditler    : {C_RED}{sayac_silinen}{C_RESET}")
    print(f"Karantinaya Alınan   : {C_YELLOW}{sayac_karantina}{C_RESET}")
    print(f"Y.Z. İzin Verilenler : {C_GREEN}{sayac_izin}{C_RESET}")
    print(f"Beyaz Listeden Geçen : {C_MAGENTA}{sayac_beyaz}{C_RESET}") # YENİ
    print("-" * 40)
    print(f"{C_GREEN}✅ Doğru Karar Sayısı  : {sayac_dogru}{C_RESET}")
    print(f"{C_RED}❌ Hatalı Karar Sayısı : {sayac_yanlis}{C_RESET} {C_YELLOW}(* Hatalar günlüğe eklendi){C_RESET}")
    print(f"{C_CYAN}🎯 SİSTEM DOĞRULUK ORANI: %{dogruluk_yuzdesi:.1f}{C_RESET}\n")

if __name__ == "__main__":
    fast_scan()