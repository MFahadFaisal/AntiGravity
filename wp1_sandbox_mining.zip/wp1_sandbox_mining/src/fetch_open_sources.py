import os
import requests
import pandas as pd
import re
import hashlib
from tqdm import tqdm

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
META_DIR = os.path.join(BASE_DIR, "metadata")
os.makedirs(META_DIR, exist_ok=True)

MAL_CATALOG = os.path.join(META_DIR, "malware_family_index.csv")
BEN_CATALOG = os.path.join(META_DIR, "benign_samples_index.csv")

# Güncellenmiş, hızlı ve 404 hatası vermeyen adresler
OPEN_SOURCES = [
    {
        "url": "https://bazaar.abuse.ch/export/csv/recent/",
        "description": "MalwareBazaar Son 24 Saat (Trojan, RAT, Ransomware)"
    },
    {
        "url": "https://urlhaus.abuse.ch/downloads/csv_recent/",
        "description": "URLhaus Son 30 Günlük Aktif Payload Hashleri"
    }
]

def fetch_balanced_data():
    print("\n" + "="*70)
    print("[*] API KULLANMADAN AÇIK KAYNAKLARDAN VERİ ÇEKİLİYOR...")
    print("="*70)
    
    new_malware_list = []
    
    # 1. ZARARLILARI ÇEK 
    for source in OPEN_SOURCES:
        print(f"\n[>] Sunucuya Bağlanılıyor: {source['description']}")
        try:
            # Sitenin bot sanıp engellememesi için tarayıcı kimliği (User-Agent) eklendi
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
            
            # Dosyayı parça parça indir (stream=True) ki ekranda donmasın
            response = requests.get(source['url'], headers=headers, stream=True, timeout=15)
            
            if response.status_code == 200:
                total_size = int(response.headers.get('content-length', 0))
                block_size = 1024 # 1 KB'lık parçalar
                text_data = ""
                
                # İndirme işlemi için ilerleme çubuğu
                with tqdm(total=total_size, unit='B', unit_scale=True, desc="İndiriliyor", leave=False) as pbar:
                    for data in response.iter_content(block_size):
                        pbar.update(len(data))
                        text_data += data.decode('utf-8', errors='ignore')
                
                # İnen metin içinden 64 karakterli SHA-256 kodlarını Regex ile bul
                found_hashes = list(set(re.findall(r'\b[a-fA-F0-9]{64}\b', text_data)))
                
                # Listeyi şişirmemek için her kaynaktan rastgele 60 tane al
                target_hashes = found_hashes[:60]
                
                for h in target_hashes:
                    new_malware_list.append({
                        "sha256": h, 
                        "family": "Mixed_Trojan_Spyware", 
                        "category": "malware", 
                        "label": 1
                    })
                print(f"  [+] İşlem Başarılı: {len(target_hashes)} adet zararlı hash bulundu ve ayıklandı.")
            else:
                print(f"  [-] Sunucu Hatası: HTTP {response.status_code}")
                
        except Exception as e:
            print(f"  [-] Bağlantı veya İndirme Hatası: {e}")

    # Zararlıları mevcut CSV'ye kaydet ve kaç tane yeni eklendiğini bul
    if os.path.exists(MAL_CATALOG):
        df_mal = pd.read_csv(MAL_CATALOG)
        old_mal_count = len(df_mal)
    else:
        df_mal = pd.DataFrame(columns=["sha256", "family", "category", "label"])
        old_mal_count = 0

    df_mal_combined = pd.concat([df_mal, pd.DataFrame(new_malware_list)]).drop_duplicates(subset=["sha256"], keep="first")
    df_mal_combined.to_csv(MAL_CATALOG, index=False)
    
    added_malware = len(df_mal_combined) - old_mal_count
    print(f"\n[+] Zararlı kataloğuna {added_malware} YENİ KAYIT eklendi. (Katalogdaki Toplam Zararlı: {len(df_mal_combined)})")

    # 2. DENGE İÇİN AYNI SAYIDA TEMİZ (BENIGN) DOSYA BUL
    if added_malware > 0:
        print(f"\n[*] Model Dengesi İçin Sistemden {added_malware} Adet YENİ TEMİZ DOSYA (.exe/.dll) Taranıyor...")
        
        if os.path.exists(BEN_CATALOG):
            df_ben = pd.read_csv(BEN_CATALOG)
            ben_rows = df_ben.to_dict('records')
            existing_benign_hashes = set(df_ben["sha256"].tolist())
        else:
            ben_rows = []
            existing_benign_hashes = set()

        search_dirs = [r"C:\Windows\SysWOW64", r"C:\Program Files\Common Files", r"C:\Windows\System32\wbem"]
        added_benign = 0
        
        with tqdm(total=added_malware, desc="Sistem Taranıyor", unit="dosya") as pbar:
            for d in search_dirs:
                if added_benign >= added_malware:
                    break
                if not os.path.exists(d):
                    continue
                    
                for root, _, files in os.walk(d):
                    if added_benign >= added_malware:
                        break
                    for file in files:
                        if file.lower().endswith((".exe", ".dll")):
                            full_p = os.path.join(root, file)
                            try:
                                with open(full_p, "rb") as f:
                                    h = hashlib.sha256(f.read()).hexdigest()
                                if h not in existing_benign_hashes:
                                    ben_rows.append({
                                        "sha256": h, 
                                        "family": "Benign_System_Extended", 
                                        "category": "benign", 
                                        "file_name": file, 
                                        "label": 0
                                    })
                                    existing_benign_hashes.add(h)
                                    added_benign += 1
                                    pbar.update(1)
                                    
                                    if added_benign >= added_malware:
                                        break
                            except:
                                continue

        if added_benign > 0:
            pd.DataFrame(ben_rows).to_csv(BEN_CATALOG, index=False)
            print(f"\n[+] Denge Başarıyla Sağlandı! Toplam Temiz Dosya: {len(ben_rows)}")
        else:
            print("\n[-] Yeterli yeni temiz dosya bulunamadı.")
    else:
        print("\n[!] Yeni zararlı hash bulunmadığı için temiz dosya araması atlandı.")

if __name__ == "__main__":
    fetch_balanced_data()