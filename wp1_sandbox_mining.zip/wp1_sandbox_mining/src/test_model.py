import os
import pandas as pd
import numpy as np
import joblib
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CSV_PATH = os.path.join(BASE_DIR, "behavioral_features_extracted.csv")
MODEL_PATH = os.path.join(BASE_DIR, "egitilmis_yapay_zeka.pkl")
ERROR_LOG_PATH = os.path.join(BASE_DIR, "hatalar_gunlugu.csv") # YENİ: Hata Günlüğü Yolu

def train_and_evaluate():
    if not os.path.exists(CSV_PATH):
        print(f"[-] Veri seti bulunamadi: {CSV_PATH}")
        return

    df = pd.read_csv(CSV_PATH)
    df.fillna(0, inplace=True)
    
    # ---> YENİ: HATA GÜNLÜĞÜ (GERİ BİLDİRİM DÖNGÜSÜ) OKUMASI <---
    if os.path.exists(ERROR_LOG_PATH):
        try:
            df_errors = pd.read_csv(ERROR_LOG_PATH)
            # Daha önce hata yapılan dosyaların hash'lerini al
            error_hashes = df_errors['sha256'].unique().tolist()
            
            if len(error_hashes) > 0:
                print(f"\n[!] DİKKAT: Hata günlüğünden {len(error_hashes)} adet 'sabıkalı' dosya tespit edildi.")
                print("[!] Yapay zeka bu dosyaları unutmasın diye ağırlıkları x20 kat artırılıyor...")
                
                # Sabıkalı dosyaların satırlarını bul
                hata_satirlari = df[df['sha256'].isin(error_hashes)]
                
                # Bu satırları ana tabloya 20'şer kez kopyala (Ağırlaştırılmış Eğitim)
                df = pd.concat([df] + [hata_satirlari]*20, ignore_index=True)
                print(f"[+] Veri seti güncellendi! Toplam eğitim boyutu: {len(df)}\n")
        except Exception as e:
            print(f"[-] Hata günlüğü okunamadı: {e}")
            
    df_numeric = df.select_dtypes(include=[np.number])
    y = df_numeric["is_malicious"]
    X = df_numeric.drop(columns=["is_malicious"])
    X_cols = X.columns.tolist()
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y)
    
    print("[*] Model egitimi basliyor (Lutfen bekleyin)...")
    
    param_grid = {
        'n_estimators': [100, 200],
        'max_depth': [10, 15, None],
        'class_weight': ['balanced']
    }
    
    rf_base = RandomForestClassifier(random_state=42)
    grid_search = GridSearchCV(estimator=rf_base, param_grid=param_grid, cv=5, n_jobs=-1, scoring='f1')
    grid_search.fit(X_train, y_train)
    
    model = grid_search.best_estimator_
    joblib.dump(model, MODEL_PATH)
    print(f"\n[+] HARIKA! Yapay zekanin yepyeni, hatasiz beyni kalici olarak kaydedildi!")
    
    THRESHOLD = 0.50 
    y_pred_proba = model.predict_proba(X_test)[:, 1]
    y_pred = (y_pred_proba >= THRESHOLD).astype(int)
    acc = accuracy_score(y_test, y_pred)
    
    print("\n" + "="*60)
    print(f"[*] HİBRİT MODEL DOĞRULUĞU : %{acc*100:.2f}")
    print("="*60)

if __name__ == "__main__":
    train_and_evaluate()