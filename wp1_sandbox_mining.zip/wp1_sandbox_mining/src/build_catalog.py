import os
import hashlib
import pandas as pd

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
META_DIR = os.path.join(BASE_DIR, "metadata")
os.makedirs(META_DIR, exist_ok=True)

# 30 Yeni Fidye Yazilimi (Ransomware) Hash'i
ADDITIONAL_MALWARE = [
    ("84c82835a5d21bbcf75a61706d8ab549", "WannaCry", "ransomware"),
    ("ed01ebfbc9eb5bbea545af4d01bf5f10", "WannaCry", "ransomware"),
    ("d7a5b3a3d2e96d99b244799015c7fa35", "LockBit", "ransomware"),
    ("fe8f07096d2a454d682057d3cfba210b", "LockBit", "ransomware"),
    ("8ba5c4943f7215286e680a6493b8c4c3", "Ryuk", "ransomware"),
    ("5c3f9a764d84a7e4b9550302b1f0c294", "Ryuk", "ransomware"),
    ("b7811ef173d1f11a43a05be870942721", "REvil", "ransomware"),
    ("af22e69312dc7e8e78864d3f56475685", "REvil", "ransomware"),
    ("016dcbb6a30eb6a7c490a618f997fbf2", "Cerber", "ransomware"),
    ("9be7342831d10202d08a552bc4b78759", "Cerber", "ransomware"),
    ("f3b25f54316a9a0f5ea258b376c66c3e", "GandCrab", "ransomware"),
    ("cd727289b4f4f46ef5b45c2250280eb4", "GandCrab", "ransomware"),
    ("7db140df987d6e66e6e22ae24b27b5e8", "Conti", "ransomware"),
    ("5b89a3f96f014e67272718e03e7c8f90", "Conti", "ransomware"),
    ("31f471e9885145aa81121685324869c9", "Babuk", "ransomware"),
    ("1f3c3b01511213f56643c16a30c0da52", "BlackCat", "ransomware"),
    ("8708c908cf4966d5e1657c9ef9186641", "BlackCat", "ransomware"),
    ("e104f147b2c95333f27b9c9d7249b6b6", "Maze", "ransomware"),
    ("c089f21f7db1270f20fa95a7201b1b0f", "Egregor", "ransomware"),
    ("da25164cf330553cf02b93e8749a9040", "STOP_Djvu", "ransomware"),
    ("a9f7bb1001a44c9b9a6900f074dcf012", "STOP_Djvu", "ransomware"),
    ("74d8b5a00a12e20562e6e39572688755", "Dharma", "ransomware"),
    ("554e20739c9f0bb353c9f28d9c22b13e", "Dharma", "ransomware"),
    ("24a142171542fbe75d8e7855018698d5", "Phobos", "ransomware"),
    ("cb5659779df5072023a85116790d98f7", "Phobos", "ransomware"),
    ("9c47051410ea8f46e3be473489b4b087", "MedusaLocker", "ransomware"),
    ("6b9a8966cf17f776a3e5c9a09968a356", "Clop", "ransomware"),
    ("d09e530b1968d9f1e18d6a36f564101e", "Locky", "ransomware"),
    ("71b6a493388e7d0b40c83ce903bc6b04", "NotPetya", "ransomware"),
    ("027cc450ef5f8c5f653329641ec1fed9", "Petya", "ransomware")
]

BENIGN_TARGETS = [
    "calc.exe", "notepad.exe", "mspaint.exe", "cmd.exe", "powershell.exe",
    "taskmgr.exe", "ping.exe", "ipconfig.exe", "netstat.exe", "whoami.exe",
    "systeminfo.exe", "xcopy.exe", "robocopy.exe", "regedit.exe", "control.exe",
    "charmap.exe", "cleanmgr.exe", "dxdiag.exe", "msinfo32.exe", "snippingtool.exe",
    "write.exe", "magnify.exe", "narrator.exe", "osk.exe", "mstsc.exe",
    "attrib.exe", "chkdsk.exe", "defrag.exe", "diskpart.exe", "driverquery.exe",
    "fc.exe", "find.exe", "findstr.exe", "getmac.exe", "gpresult.exe",
    "hostname.exe", "nbtstat.exe", "pathping.exe", "powercfg.exe", "qprocess.exe",
    "resmon.exe", "rundll32.exe", "sc.exe", "schtasks.exe", "sfc.exe",
    "shutdown.exe", "sort.exe", "subst.exe", "systemreset.exe", "tar.exe",
    "taskkill.exe", "tasklist.exe", "timeout.exe", "tracert.exe", "tree.com",
    "typeperf.exe", "tzutil.exe", "ver.exe", "vol.exe", "vssadmin.exe"
]

def build_catalogs():
    # 1. ZARARLI KATALOĞU (Doğru dosya adı: malware_family_index.csv)
    mal_path = os.path.join(META_DIR, "malware_family_index.csv")
    mal_rows = []
    
    if os.path.exists(mal_path):
        old_mal_df = pd.read_csv(mal_path)
        mal_rows.extend(old_mal_df.to_dict('records'))
        
    for h, f, c in ADDITIONAL_MALWARE:
        mal_rows.append({"sha256": h, "family": f, "category": c, "label": 1})
        
    df_mal = pd.DataFrame(mal_rows)
    if not df_mal.empty:
        df_mal = df_mal.drop_duplicates(subset=["sha256"], keep="first")
        df_mal.to_csv(mal_path, index=False)
        print(f"[+] Zararli katalogu basariyla guncellendi: Toplam {len(df_mal)} zararli ornek var.")

    # 2. TEMİZ KATALOG (benign_samples_index.csv)
    ben_path = os.path.join(META_DIR, "benign_samples_index.csv")
    ben_rows = []
    
    if os.path.exists(ben_path):
        old_ben_df = pd.read_csv(ben_path)
        ben_rows.extend(old_ben_df.to_dict('records'))
        
    sys32 = "C:\\Windows\\System32"
    for exe in BENIGN_TARGETS:
        full_p = os.path.join(sys32, exe)
        if os.path.exists(full_p):
            try:
                with open(full_p, "rb") as f:
                    h = hashlib.sha256(f.read()).hexdigest()
                ben_rows.append({"sha256": h, "family": "Benign_System", "category": "benign", "file_name": exe, "label": 0})
            except Exception:
                continue
                
    df_ben = pd.DataFrame(ben_rows)
    if not df_ben.empty:
        df_ben = df_ben.drop_duplicates(subset=["sha256"], keep="first")
        df_ben.to_csv(ben_path, index=False)
        print(f"[+] Benign katalogu basariyla guncellendi: Toplam {len(df_ben)} temiz ornek var.")

if __name__ == "__main__":
    build_catalogs()