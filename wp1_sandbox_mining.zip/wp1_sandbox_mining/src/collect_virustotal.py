import os
import time
import requests
import pandas as pd
import api_config

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
META_DIR = os.path.join(BASE_DIR, "metadata")
RAW_DIR = os.path.join(BASE_DIR, "raw_reports")
os.makedirs(RAW_DIR, exist_ok=True)

MAL_CATALOG = os.path.join(META_DIR, "malware_family_index.csv")
BEN_CATALOG = os.path.join(META_DIR, "benign_samples_index.csv")

# API Anahtarlarını ve Bekleme Süresini config'den al
API_KEYS = api_config.API_KEYS.get("VIRUSTOTAL", [])
BASE_DELAY = api_config.DELAYS.get("VIRUSTOTAL", 15.0)

if not API_KEYS:
    print("[-] HATA: api_config.py icinde VIRUSTOTAL API anahtari bulunamadi!")
    exit()

def get_report(sha256, api_key):
    url = f"https://www.virustotal.com/api/v3/files/{sha256}/behaviour_summary"
    headers = {"x-apikey": api_key}
    try:
        resp = requests.get(url, headers=headers, timeout=15)
        if resp.status_code == 200:
            return resp.text
        return None
    except:
        return None

def download_reports(catalog_path):
    if not os.path.exists(catalog_path):
        print(f"[-] Katalog bulunamadi: {catalog_path}")
        return

    df = pd.read_csv(catalog_path)
    total = len(df)
    key_count = len(API_KEYS)
    
    # Eger birden fazla anahtar varsa, bekleme suresini anahtar sayisina bol
    dynamic_delay = (BASE_DELAY * 4 / (key_count * 4)) + 0.5 if key_count > 0 else BASE_DELAY

    print(f"[*] Toplam {total} kayit taranacak. (Kullanilan API Anahtari: {key_count}, Bekleme: {dynamic_delay:.1f} sn)")

    for idx, row in df.iterrows():
        sha256 = row['sha256']
        out_path = os.path.join(RAW_DIR, f"{sha256}.json")
        
        if os.path.exists(out_path):
            continue # Zaten inmişse atla

        current_key = API_KEYS[idx % key_count]
        print(f"[{idx+1}/{total}] Indiriliyor: {sha256[:12]}...")
        
        report_data = get_report(sha256, current_key)
        if report_data:
            with open(out_path, "w", encoding="utf-8") as f:
                f.write(report_data)
        
        time.sleep(dynamic_delay)

if __name__ == "__main__":
    print("--- 1/2: ZARARLI DOSYALAR ---")
    download_reports(MAL_CATALOG)
    print("\n--- 2/2: TEMIZ (BENIGN) DOSYALAR ---")
    download_reports(BEN_CATALOG)
    print("\n[+] Islem tamamlandi!")