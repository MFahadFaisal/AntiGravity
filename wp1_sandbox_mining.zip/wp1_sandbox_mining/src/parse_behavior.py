import os
import json
import pandas as pd

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW_DIR = os.path.join(BASE_DIR, "raw_reports")
META_DIR = os.path.join(BASE_DIR, "metadata")
CSV_OUT = os.path.join(BASE_DIR, "behavioral_features_extracted.csv")

def load_labels():
    labels = {}
    if os.path.exists(os.path.join(META_DIR, "malware_family_index.csv")):
        df_mal = pd.read_csv(os.path.join(META_DIR, "malware_family_index.csv"))
        for _, row in df_mal.iterrows():
            labels[row['sha256']] = (1, row.get('family', 'Malware'))
    
    if os.path.exists(os.path.join(META_DIR, "benign_samples_index.csv")):
        df_ben = pd.read_csv(os.path.join(META_DIR, "benign_samples_index.csv"))
        for _, row in df_ben.iterrows():
            labels[row['sha256']] = (0, row.get('family', 'Benign'))
    return labels

def find_list_length(data, target_key):
    if isinstance(data, dict):
        if target_key in data:
            val = data[target_key]
            return len(val) if isinstance(val, list) else 1
        for k, v in data.items():
            res = find_list_length(v, target_key)
            if res > 0: return res
    elif isinstance(data, list):
        for item in data:
            res = find_list_length(item, target_key)
            if res > 0: return res
    return 0

def parse_all():
    labels = load_labels()
    parsed_data = []
    
    if not os.path.exists(RAW_DIR):
        print("[-] Rapor klasoru bulunamadi.")
        return
        
    for file in os.listdir(RAW_DIR):
        if not file.endswith(".json"): continue
        sha256 = file.replace(".json", "")
        
        if sha256 not in labels: continue
        is_mal, family = labels[sha256]
        
        try:
            with open(os.path.join(RAW_DIR, file), "r", encoding="utf-8") as f:
                data = json.load(f)
        except:
            continue
            
        files_written = find_list_length(data, "files_written")
        files_created = find_list_length(data, "files_created")
        files_deleted = find_list_length(data, "files_deleted")
        registry_set = find_list_length(data, "registry_keys_set")
        registry_opened = find_list_length(data, "registry_keys_opened")
        processes_created = find_list_length(data, "processes_created")
        ip_traffic = find_list_length(data, "ip_traffic")
        
        registry_ops = registry_set + registry_opened
        file_churn = files_written + files_deleted
        write_per_proc = files_written / (processes_created + 1.0)
        network_threat = ip_traffic / (files_written + 1.0)
        
        raw_text = str(data).lower()
        cmd_flag = 1 if "cmd.exe" in raw_text or "powershell" in raw_text else 0
        ransomware_flag = 1 if files_written > 10 and files_deleted > 5 else 0
        
        # ---> FİNAL: SİBER POLİS VE HİBRİT CEZA PUANI MANTIĞI <---
        risk_score = 0
        if cmd_flag == 1: 
            risk_score += 30
        if ransomware_flag == 1: 
            risk_score += 50
        
        # KURAL 1: Sessiz Hırsız (Stealer) - Dosya yazmaz ama registry okuyup IP'ye veri yollar
        if files_written == 0 and ip_traffic > 0 and registry_opened > 5:
            risk_score += 45
            
        # KURAL 2: Ölü Taklidi (Sandbox Evasion) - KOPYA ÇEKMEK YOK, sadece davranış
        # Hiçbir şey yapmıyorsa bu normal bir program değildir, analizden kaçıyordur!
        if files_written == 0 and registry_opened == 0 and ip_traffic == 0:
            risk_score += 45
            
        if network_threat > 2.0: 
            risk_score += 40
        if registry_ops > 10: 
            risk_score += 20
        if file_churn > 50: 
            risk_score += 20
            
        parsed_data.append({
            "sha256": sha256,
            "family": family,
            "is_malicious": is_mal,
            "files_written_count": files_written,
            "files_created_count": files_created,
            "files_deleted_count": files_deleted,
            "registry_ops_count": registry_ops,
            "processes_spawned_count": processes_created,
            "network_outbound_ips": ip_traffic,
            "file_churn": file_churn,                     
            "write_per_proc": round(write_per_proc, 3),   
            "network_threat_score": round(network_threat, 3), 
            "cmd_flag": cmd_flag,
            "ransomware_encryption_flag": ransomware_flag,
            "heuristic_risk_score": risk_score
        })
        
    df = pd.DataFrame(parsed_data)
    df.fillna(0, inplace=True)
    df.to_csv(CSV_OUT, index=False)
    print(f"[+] BASARILI! Hibrit kurallar (Stealer + Evasion) CSV'ye islendi. Kayit: {len(df)}")

if __name__ == "__main__":
    parse_all()