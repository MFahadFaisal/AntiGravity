# api_config.py

API_KEYS = {
    "VIRUSTOTAL": [
    "061ea323c7c6e5c4c7c1db7b677a5e18bc3ee268120f6d6ca1707bede573be93",
    "4e68ed080976762d79086462dce2650a13491f9203960463e4b8f01dbe6ac01d",
    "02a9e9bb7101e9c1610acd120be1496fa4b08339d1e9eef65c143a3f6e71d4d0",
    "06209d28263d8972e97125e5a37df5b78ab10790d0f3b99e57e4acaafcb268cf"

  ],
    
    "MALWARE_BAZAAR": "SENIN_MALWARE_BAZAAR_API_KEY",
    
    "HYBRID_ANALYSIS": "hxaqz85q85e4327fpcs3uzlpa7949dabh6xfnblzdf7320100v8omuond1988e4f",
    
    "ALIENVAULT_OTX": "47c23c229b679e81fa2df4a474e52caf173acfbfdfe735334c963ab19c082e3f"
}

DELAYS = {
    "VIRUSTOTAL": 15.0,        # Dakikada 4 istek siniri
    "HYBRID_ANALYSIS": 12.0,   # Dakikada 5 istek siniri
    "MALWARE_BAZAAR": 1.0,     # Spam onleme beklemesi
    "ALIENVAULT_OTX": 1.0      # Limit yok ama sunucuyu yormamak icin
}
